#!/usr/bin/env python3
"""
Zero-shot transfer check for the mean_first5 / mean_first_sentence pooling
variant probes -> the 4-way sycophancy_mixture. Batched rather than one run
per probe (unlike truthfulqa_probe_transfer_pipeline.py): every category's
row in mixture.jsonl gets the same single forward pass over row["text"]
(the moral-category two-pass special-case in that script only triggers for
the standalone --targets moral file, not --targets mixture), so mixture
activations for a given pooling mode are extracted ONCE and every probe
trained with that pooling mode is scored against the same cached
activations instead of re-extracting per probe.

Usage:
    python pooling_variant_transfer_batch.py --pooling mean_first5
    python pooling_variant_transfer_batch.py --pooling mean_first_sentence
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SYCOPHANCY_DIR = HERE.parent
REPO_ROOT = HERE.parents[3]
for p in (SYCOPHANCY_DIR, REPO_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from utils.model import load_model_and_tokenizer, cleanup as cleanup_model
from sycophancy_model_registry import get_model_config
from sycophancy_probes import LinearProbe, _probe_accuracy, _probe_scores, _fold_auc, wilson_ci
from mixture_residual_probe_pipeline import collect_residual_only
from truthfulqa_probe_transfer_pipeline import bootstrap_auc_ci, score_by_group

GENERATIONS_DIR = SYCOPHANCY_DIR / "results" / "generations"
PROBING_DIR = SYCOPHANCY_DIR / "results" / "probing"
MIXTURE_PATH = GENERATIONS_DIR / "sycophancy_mixture" / "mixture.jsonl"

# probe name -> {pooling: best_layer}, from pooling_variant_comparison.md
PROBES = {
    "sypr": {"mean_first5": 22, "mean_first_sentence": 27},
    "are_you_sure": {"mean_first5": 13, "mean_first_sentence": 13},
    "social": {"mean_first5": 14, "mean_first_sentence": 11},
    "truthfulqa": {"mean_first5": 15, "mean_first_sentence": 29},
    "moral_avg": {"mean_first5": 31, "mean_first_sentence": 30},
}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pooling", type=str, required=True, choices=["mean_first5", "mean_first_sentence"])
    parser.add_argument("--model", type=str, default="meta-llama/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--output-dir", type=str, default=None)
    args = parser.parse_args()

    suffix = "_first5" if args.pooling == "mean_first5" else "_first_sentence"
    out_dir = Path(args.output_dir) if args.output_dir else (
        SYCOPHANCY_DIR / "results" / "cross_domain_transfer" / f"pooling_variant_transfer_{args.pooling}"
    )

    rows = [json.loads(line) for line in open(MIXTURE_PATH, encoding="utf-8")]
    texts = [r["text"] for r in rows]
    labels = np.array([r["label"] for r in rows], dtype=np.float32)
    categories = [r.get("category") for r in rows]
    print(f"Loaded {len(rows)} mixture rows ({int((labels==1).sum())} positive / {int((labels==0).sum())} negative)")

    print(f"\nLoading {args.model}...")
    model, tokenizer = load_model_and_tokenizer(args.model)
    model_config = get_model_config(args.model)
    model_config["model_name"] = args.model
    n_layers = model_config["n_layers"]

    print(f"\nExtracting mixture residual activations ONCE with pooling={args.pooling!r} ({n_layers} layers)...")
    activations = collect_residual_only(model, tokenizer, texts, model_config, pooling=args.pooling)
    cleanup_model(model, tokenizer)

    all_results = {"pooling": args.pooling, "mixture_input": str(MIXTURE_PATH), "probes": {}}
    for probe_name, layer_map in PROBES.items():
        layer = layer_map[args.pooling]
        weights_path = PROBING_DIR / f"{probe_name}_residual{suffix}" / "residual_probe_weights.pth"
        weights_ckpt = torch.load(weights_path, map_location="cpu", weights_only=False)
        state_dict = weights_ckpt[layer]
        input_dim = state_dict["linear.weight"].shape[1]
        probe = LinearProbe(input_dim)
        probe.load_state_dict(state_dict)
        probe.eval()

        X = activations[layer]
        finite_mask = np.isfinite(X).all(axis=1)
        n_dropped_nan = int((~finite_mask).sum())
        Xg = X[finite_mask]
        yg = labels[finite_mask]
        catsg = [c for c, keep in zip(categories, finite_mask) if keep]

        scores = score_by_group(probe, Xg, yg, catsg)
        all_results["probes"][probe_name] = {
            "weights_source": str(weights_path), "layer": layer, "n_dropped_nan": n_dropped_nan, "scores": scores,
        }
        overall = scores["__all__"]
        print(f"[{probe_name}] layer={layer} overall: accuracy={overall['accuracy']:.3f} CI={overall['ci']} "
              f"AUC={overall['auc_roc']} AUC_CI={overall['auc_roc_ci']}")
        for cat, r in scores.items():
            if cat == "__all__":
                continue
            print(f"    {cat}: accuracy={r['accuracy']:.3f} (n={r['n']}) AUC={r['auc_roc']}")

    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "results.json", "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nDone. Results written to {out_dir / 'results.json'}")


if __name__ == "__main__":
    main()
