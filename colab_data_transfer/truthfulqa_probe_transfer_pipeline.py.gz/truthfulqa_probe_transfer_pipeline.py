#!/usr/bin/env python3
"""
Zero-shot transfer check: does the best-layer TruthfulQA residual probe
(layer 13 by default, trained via `category_residual_probe_pipeline.py
--categories truthfulqa`) generalize to other sycophancy datasets it was
never trained on? No retraining -- the frozen layer-13 nn.Linear probe is
scored directly against fresh residual activations extracted from each
target dataset, mirroring oeq_probe_aita_transfer_pipeline.py's score_probe
pattern (that script's LinearProbe reconstruction + Wilson-CI scoring,
generalized here to arbitrary target datasets instead of a single
OEQ->AITA check).

Targets:
    mixture      results/generations/sycophancy_mixture/mixture.jsonl (2,840
                 rows, 4-way balanced sypr/social/moral/are_you_sure mixture --
                 per-category accuracy breakdown reported since it carries a
                 "category" field)
    sypr         results/generations/sypr_praise_llama31_full/checkpoint.jsonl (full)
    social       results/generations/social_sycophancy_pooled/pooled.jsonl (full)
    truthfulqa   results/generations/truthfulqa_sycophancyeval/checkpoint.jsonl (full)
    are_you_sure results/generations/are_you_sure_pooled/pooled.jsonl (full, uncapped --
                 same file build_sycophancy_mixture.py draws its are_you_sure rows
                 from, natural ~50/50 balance so no calibration skew expected)
    moral        AITA-NTA-FLIP_moral_sycophancy_judged.jsonl, full judged pool
                 (no capping, unlike moral_avg_residual_probe_pipeline.py's own
                 370/370 training split) -- special-cased: unlike the other
                 targets' single forward pass over row["text"], moral needs
                 TWO forward passes per pair (original post, flipped story)
                 averaged per layer, same fix as moral_avg_residual_probe_
                 pipeline.py, because its label depends on both sides' verdict
                 and there's no pre-built single "text" field for it.

Usage:
    python truthfulqa_probe_transfer_pipeline.py \
        --probe-dir results/probing/truthfulqa_residual --layer 13 \
        --targets mixture --model meta-llama/Meta-Llama-3-8B-Instruct
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SYCOPHANCY_DIR = HERE.parent
REPO_ROOT = HERE.parents[3]
for p in (SYCOPHANCY_DIR, REPO_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from sklearn.metrics import roc_auc_score

from utils.model import load_model_and_tokenizer, cleanup as cleanup_model
from utils.inference import build_chat_prompt
from sycophancy_model_registry import get_model_config
from sycophancy_probes import LinearProbe, _probe_accuracy, _probe_scores, _fold_auc, wilson_ci
from mixture_residual_probe_pipeline import collect_residual_only

GENERATIONS_DIR = SYCOPHANCY_DIR / "results" / "generations"
DEFAULT_MORAL_JUDGED = GENERATIONS_DIR / "AITA-NTA-FLIP_moral_sycophancy_judged.jsonl"

TARGETS = {
    "mixture": GENERATIONS_DIR / "sycophancy_mixture" / "mixture.jsonl",
    "sypr": GENERATIONS_DIR / "sypr_praise_llama31_full" / "checkpoint.jsonl",
    "social": GENERATIONS_DIR / "social_sycophancy_pooled" / "pooled.jsonl",
    "truthfulqa": GENERATIONS_DIR / "truthfulqa_sycophancyeval" / "checkpoint.jsonl",
    "are_you_sure": GENERATIONS_DIR / "are_you_sure_pooled" / "pooled.jsonl",
    "moral": DEFAULT_MORAL_JUDGED,
    "syconbench": GENERATIONS_DIR / "syconbench" / "conversations.jsonl",
    "dissociating_sycophancy": GENERATIONS_DIR / "dissociating_sycophancy" / "conversations_judged.jsonl",
}

# syconbench's 5-turn conversations run 571-2705 tokens (mean ~1675) -- well
# past the 1024-token default, and truncation_side="right" would cut off the
# final turn we're scoring rather than the start. See category_residual_
# probe_pipeline.py's CATEGORY_MAX_LENGTH for the same issue on the training side.
TARGET_MAX_LENGTH = {
    "syconbench": 3072,
}

# syconbench's "ever flipped" label reflects the WHOLE 5-turn conversation,
# not just the final turn -- default "mean" pooling (last delimiter to end)
# only covers the final turn, which mismatches label scope for the ~80% of
# positive examples that flip early then recover by the end (verified
# against debate_setting's own alignment arrays). "mean_all_turns" pools
# every assistant turn's response tokens instead, matching label scope.
TARGET_POOLING = {
    "syconbench": "mean_all_turns",
}


def load_target(path: Path) -> tuple:
    rows = [json.loads(line) for line in open(path, encoding="utf-8")]
    texts = [r["text"] for r in rows]
    labels = np.array([r["label"] for r in rows], dtype=np.float32)
    # mixture rows have "category" (sypr/social/moral/are_you_sure); truthfulqa
    # rows instead have "template" (plain vs. pushback_incorrect) -- falling
    # back to it lets score_by_group break out a per-template accuracy/AUC for
    # truthfulqa (whether social pressure was actually present) for free,
    # without a separate filtered target or extraction pass.
    categories = [r.get("category") or r.get("template") for r in rows]
    return texts, labels, categories


def load_moral_pairs(path: Path) -> tuple:
    """Full (uncapped) moral judged pool, same label definition as
    moral_avg_residual_probe_pipeline.py's select_moral_pairs: positive =
    both NTA, negative = both YTA or either side OTHER/unclear, Mixed pairs
    (one NTA one YTA) excluded entirely. Returns (rows, labels) -- caller
    builds og/flip chat-prompt texts with the tokenizer and extracts
    activations for each side separately."""
    rows = [json.loads(line) for line in open(path, encoding="utf-8")]
    selected, labels = [], []
    for r in rows:
        og, flip = r["original_post_verdict"], r["flipped_story_verdict"]
        if og == "NTA" and flip == "NTA":
            label = 1
        elif (og == "NTA" and flip == "YTA") or (og == "YTA" and flip == "NTA"):
            continue  # Mixed -- excluded
        else:
            label = 0  # both YTA, or either side OTHER
        selected.append(r)
        labels.append(label)
    return selected, np.array(labels, dtype=np.float32)


def bootstrap_auc_ci(y: np.ndarray, scores: np.ndarray, n_bootstrap: int = 1000, alpha: float = 0.05, seed: int = 42):
    """Percentile bootstrap CI for a single-shot AUC-ROC point estimate --
    resamples (label, score) pairs together (not scores alone, since AUC is
    a function of the pairing) and recomputes roc_auc_score each draw.
    Distinct from sycophancy_probes.bootstrap_ci, which bootstraps a 1-D
    array of already-computed per-fold statistics rather than raw examples.
    Returns None if every draw collapses to a single class (tiny/imbalanced
    groups) -- same "no signal" convention as _fold_auc returning None."""
    rng = np.random.default_rng(seed)
    n = len(y)
    boots = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        y_b = y[idx]
        if len(np.unique(y_b)) < 2:
            continue
        boots.append(roc_auc_score(y_b, scores[idx]))
    if not boots:
        return None
    lo = float(np.percentile(boots, 100 * alpha / 2))
    hi = float(np.percentile(boots, 100 * (1 - alpha / 2)))
    return (lo, hi)


def score_by_group(probe, X: np.ndarray, labels: np.ndarray, groups: list) -> dict:
    """Accuracy/CI/AUC(+CI) for the full set plus each distinct group value
    (e.g. mixture's "category" field) -- None group values are skipped as
    their own bucket (non-mixture targets have no category field at all)."""
    out = {}
    for name, idx in [("__all__", list(range(len(labels))))] + [
        (g, [i for i, gg in enumerate(groups) if gg == g]) for g in sorted(set(groups)) if g is not None
    ]:
        Xg, yg = X[idx], labels[idx]
        n_correct, n_total, accuracy = _probe_accuracy(probe, Xg, yg)
        ci = wilson_ci(n_correct, n_total)
        scores_g = _probe_scores(probe, Xg)
        auc = _fold_auc(yg, scores_g)
        auc_ci = bootstrap_auc_ci(yg, scores_g) if auc is not None else None
        out[name] = {
            "n": n_total, "n_pos": int((yg == 1).sum()),
            "accuracy": accuracy, "ci": ci,
            "auc_roc": auc, "auc_roc_ci": auc_ci,
        }
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--probe-dir", type=str, default=str(SYCOPHANCY_DIR / "results" / "probing" / "truthfulqa_residual"))
    parser.add_argument("--layer", type=int, default=13, help="Layer of the saved probe checkpoint to score with (default: the trained best layer).")
    parser.add_argument("--targets", type=str, default="mixture", help="Comma-separated subset of: " + ",".join(TARGETS.keys()))
    parser.add_argument("--model", type=str, default="meta-llama/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--output-dir", type=str, default=str(SYCOPHANCY_DIR / "results" / "cross_domain_transfer" / "truthfulqa_probe_transfer"))
    args = parser.parse_args()

    selected = args.targets.split(",")
    for name in selected:
        if name not in TARGETS:
            print(f"ERROR: unknown target {name!r}, must be one of {list(TARGETS)}", file=sys.stderr)
            sys.exit(1)

    weights_path = Path(args.probe_dir) / "residual_probe_weights.pth"
    weights_ckpt = torch.load(weights_path, map_location="cpu", weights_only=False)
    if args.layer not in weights_ckpt:
        print(f"ERROR: layer {args.layer} not in {weights_path} (available: {sorted(weights_ckpt)})", file=sys.stderr)
        sys.exit(1)
    state_dict = weights_ckpt[args.layer]
    input_dim = state_dict["linear.weight"].shape[1]
    probe = LinearProbe(input_dim)
    probe.load_state_dict(state_dict)
    probe.eval()
    print(f"Loaded frozen probe from {weights_path} @ layer {args.layer} (input_dim={input_dim})")

    print(f"\nLoading {args.model}...")
    model, tokenizer = load_model_and_tokenizer(args.model)
    model_config = get_model_config(args.model)
    model_config["model_name"] = args.model
    n_layers = model_config["n_layers"]

    all_results = {"probe_source": str(weights_path), "probe_layer": args.layer, "model": args.model, "targets": {}}
    for name in selected:
        path = TARGETS[name]
        print(f"\n{'='*70}\nTarget: {name}  ({path})\n{'='*70}")

        if name == "moral":
            rows, labels = load_moral_pairs(path)
            n_pos, n_neg = int((labels == 1).sum()), int((labels == 0).sum())
            print(f"Loaded {len(rows)} pairs ({n_pos} positive / {n_neg} negative, Mixed excluded)")

            og_texts = [build_chat_prompt(tokenizer, r["original_post_prompt"], system_prompt=None) + r["original_post_response"] for r in rows]
            flip_texts = [build_chat_prompt(tokenizer, r["flipped_story_prompt"], system_prompt=None) + r["flipped_story_response"] for r in rows]
            print(f"Extracting residual activations for {len(rows)} pairs, original-post side...")
            og_activations = collect_residual_only(model, tokenizer, og_texts, model_config)
            print(f"Extracting residual activations for {len(rows)} pairs, flipped-story side...")
            flip_activations = collect_residual_only(model, tokenizer, flip_texts, model_config)
            residual_activations = (og_activations + flip_activations) / 2.0
            X = residual_activations[args.layer]
            categories = [None] * len(rows)
            n_total = len(rows)
        else:
            texts, labels, categories = load_target(path)
            n_pos, n_neg = int((labels == 1).sum()), int((labels == 0).sum())
            print(f"Loaded {len(texts)} rows ({n_pos} positive / {n_neg} negative)")

            max_length = TARGET_MAX_LENGTH.get(name, 1024)
            target_pooling = TARGET_POOLING.get(name, "mean")
            print(f"Extracting residual-stream activations for {len(texts)} examples ({n_layers} layers, max_length={max_length}, pooling={target_pooling!r})...")
            residual_activations = collect_residual_only(model, tokenizer, texts, model_config, max_length=max_length, pooling=target_pooling)
            X = residual_activations[args.layer]  # (n_examples, hidden_dim)
            n_total = len(texts)

        finite_mask = np.isfinite(X).all(axis=1)
        n_dropped_nan = int((~finite_mask).sum())
        if n_dropped_nan:
            print(f"WARNING: dropping {n_dropped_nan} row(s) with non-finite residual activations "
                  f"(likely empty/degenerate response span for the pooling window) before scoring")
            X = X[finite_mask]
            labels = labels[finite_mask]
            categories = [c for c, keep in zip(categories, finite_mask) if keep]

        scores = score_by_group(probe, X, labels, categories)
        all_results["targets"][name] = {
            "n_total": n_total, "n_pos": n_pos, "n_neg": n_neg,
            "n_dropped_nan": n_dropped_nan, "scores": scores,
        }

        overall = scores["__all__"]
        print(f"[{name}] overall: accuracy={overall['accuracy']:.3f} CI=[{overall['ci'][0]:.3f},{overall['ci'][1]:.3f}] "
              f"AUC={overall['auc_roc']} AUC_CI={overall['auc_roc_ci']}")
        for cat, r in scores.items():
            if cat == "__all__":
                continue
            print(f"    {cat}: accuracy={r['accuracy']:.3f} CI=[{r['ci'][0]:.3f},{r['ci'][1]:.3f}] "
                  f"(n={r['n']}, n_pos={r['n_pos']}) AUC={r['auc_roc']} AUC_CI={r['auc_roc_ci']}")

        del residual_activations
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    cleanup_model(model, tokenizer)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "results.json", "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nDone. Results written to {out_dir / 'results.json'}")


if __name__ == "__main__":
    main()
