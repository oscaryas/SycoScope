#!/usr/bin/env python3
"""
Trains residual-stream-only linear probes separately for each sycophancy
category (not mixed, unlike mixture_residual_probe_pipeline.py) -- one probe
set per category, each on that category's own full pooled/generated dataset,
undersampled down to that dataset's own minority-class count BEFORE
activation extraction (not the shared cross-category cap
build_sycophancy_mixture.py uses, and not train_probe's internal per-call
undersampling -- pre-sampling here means no GPU time is spent extracting
activations for majority-class rows that would just be discarded anyway):
    sypr          results/generations/sypr_praise_llama31_full/checkpoint.jsonl
    social        results/generations/social_sycophancy_pooled/pooled.jsonl
    truthfulqa    results/generations/truthfulqa_sycophancyeval/checkpoint.jsonl
    are_you_sure  results/generations/are_you_sure_freeform/checkpoint.jsonl

moral is deliberately NOT included here -- moral_avg_residual_probe_
pipeline.py handles it separately (two forward passes per pair, original
post + flipped story, averaged per layer) because moral's pooled.jsonl
"text" field concatenates both halves into one string that truncates at
max_length=1024, silently dropping the flipped-story half for most rows.

Model is loaded once and reused across all selected categories (each just
needs a fresh residual-activation extraction pass) rather than reloading the
8B model per category. Same lean residual-only extraction as
mixture_residual_probe_pipeline.py -- no MHA/MLP hooks, no MHA/MLP probe
training.

Usage:
    python category_residual_probe_pipeline.py \
        --output-dir results/probing --model meta-llama/Meta-Llama-3-8B-Instruct
"""
import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SYCOPHANCY_DIR = HERE.parent
REPO_ROOT = HERE.parents[3]
for p in (SYCOPHANCY_DIR, REPO_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from utils.model import load_model_and_tokenizer, cleanup as cleanup_model
from sycophancy_model_registry import get_model_config
from sycophancy_probes import train_residual_probes, save_probe_results
from mixture_residual_probe_pipeline import collect_residual_only

GENERATIONS_DIR = SYCOPHANCY_DIR / "results" / "generations"

CATEGORIES = {
    "sypr": GENERATIONS_DIR / "sypr_praise_llama31_full" / "checkpoint.jsonl",
    # Full pooled dataset (MC + freeform, matching what build_sycophancy_mixture.py
    # itself draws from for the mixture's are_you_sure category) -- NOT the
    # freeform-only subset (are_you_sure_freeform/checkpoint.jsonl, 1,090 rows).
    "are_you_sure": GENERATIONS_DIR / "are_you_sure_pooled" / "pooled.jsonl",
    "social": GENERATIONS_DIR / "social_sycophancy_pooled" / "pooled.jsonl",
    "truthfulqa": GENERATIONS_DIR / "truthfulqa_sycophancyeval" / "checkpoint.jsonl",
    # 5-turn escalating-pressure conversations (debate/ethical/false-presup
    # combined) -- long by construction, needs a larger --max-length than the
    # 1024 default or the final turn we want to pool gets truncated away.
    "syconbench": GENERATIONS_DIR / "syconbench" / "conversations.jsonl",
    # 2-turn caving-under-baseless-pushback conversations, Claude-judged
    # (see dissociating_sycophancy_generate.py) -- short, default max_length is fine.
    "dissociating_sycophancy": GENERATIONS_DIR / "dissociating_sycophancy" / "conversations_judged.jsonl",
}

# syconbench's conversations run 571-2705 tokens (mean ~1675) since each row
# threads 5 real response turns into history -- well past the 1024-token
# default, and truncation_side="right" means the default would cut off the
# very final response (what we pool) rather than the start.
CATEGORY_MAX_LENGTH = {
    "syconbench": 3072,
}


def load_dataset(path: Path, seed: int) -> tuple:
    """Loads {text, label} rows and undersamples to this dataset's own
    min(n_pos, n_neg) -- same pre-extraction capping moral_avg_residual_
    probe_pipeline.py's select_moral_pairs does for moral, generalized to
    any single-text-per-row category."""
    rows = [json.loads(line) for line in open(path, encoding="utf-8")]
    pos = [r for r in rows if r["label"] == 1]
    neg = [r for r in rows if r["label"] == 0]
    n = min(len(pos), len(neg))
    print(f"  Full dataset: {len(pos)} positive / {len(neg)} negative -- capping to {n}/{n} (minority class)")
    rng = random.Random(seed)
    sampled = rng.sample(pos, n) + rng.sample(neg, n)
    rng.shuffle(sampled)
    texts = [r["text"] for r in sampled]
    labels = np.array([r["label"] for r in sampled], dtype=np.float32)
    return texts, labels


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--output-dir", type=str, default=str(SYCOPHANCY_DIR / "results" / "probing"))
    parser.add_argument("--model", type=str, default="meta-llama/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--balance-method", type=str, default="undersample", choices=["undersample", "upweight"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--categories", type=str, default=",".join(CATEGORIES.keys()),
                         help="Comma-separated subset of: " + ",".join(CATEGORIES.keys()))
    parser.add_argument("--pooling", type=str, default="mean",
                         help="'mean' (full response span, default) or 'mean_first<K>' "
                              "(e.g. 'mean_first5') to pool only the response's first K tokens. "
                              "Output dir gets a _first<K> suffix for any non-'mean' pooling so "
                              "results land alongside the full-response ones, not over them.")
    args = parser.parse_args()

    selected = args.categories.split(",")
    for name in selected:
        if name not in CATEGORIES:
            print(f"ERROR: unknown category {name!r}, must be one of {list(CATEGORIES)}", file=sys.stderr)
            sys.exit(1)

    print(f"Loading {args.model}...")
    model, tokenizer = load_model_and_tokenizer(args.model)
    model_config = get_model_config(args.model)
    model_config["model_name"] = args.model
    n_layers = model_config["n_layers"]

    all_metadata = {}
    for name in selected:
        path = CATEGORIES[name]
        print(f"\n{'='*70}\nCategory: {name}  ({path})\n{'='*70}")
        texts, labels = load_dataset(path, args.seed)
        n_pos = int((labels == 1).sum())
        n_neg = int((labels == 0).sum())
        print(f"Capped to {len(texts)} rows ({n_pos} positive / {n_neg} negative)")

        max_length = CATEGORY_MAX_LENGTH.get(name, 1024)
        print(f"Extracting residual-stream activations for {len(texts)} examples ({n_layers} layers, pooling={args.pooling!r}, max_length={max_length})...")
        residual_activations = collect_residual_only(model, tokenizer, texts, model_config, max_length=max_length, pooling=args.pooling)

        print(f"Training residual probes (balance_method={args.balance_method})...")
        res_acc, res_ci, res_states, res_auc, res_auc_ci = train_residual_probes(
            residual_activations, labels, n_layers, balance_method=args.balance_method, seed=args.seed,
        )

        results = {
            "mha_accuracy": {}, "mha_ci": {}, "mha_states": {}, "mha_auc": {}, "mha_auc_ci": {},
            "mlp_accuracy": {}, "mlp_ci": {}, "mlp_states": {}, "mlp_auc": {}, "mlp_auc_ci": {},
            "residual_accuracy": res_acc, "residual_ci": res_ci, "residual_states": res_states,
            "residual_auc": res_auc, "residual_auc_ci": res_auc_ci,
        }
        pooling_suffix = "" if args.pooling == "mean" else f"_{args.pooling.replace('mean_', '')}"
        out_dir = Path(args.output_dir) / f"{name}_residual{pooling_suffix}"
        metadata = save_probe_results(results, str(out_dir), model_name=args.model)

        run_info = {
            "input": str(path), "category": name, "n_total": len(texts),
            "n_pos": n_pos, "n_neg": n_neg,
            "balance_method": args.balance_method, "model": args.model, "seed": args.seed,
            "pooling": args.pooling, "max_length": max_length,
            "note": "pre-sampled to this dataset's own min(n_pos, n_neg) before activation "
                    "extraction (not the shared cross-category cap from sycophancy_mixture, and "
                    "not the full raw dataset)",
        }
        with open(out_dir / "run_info.json", "w") as f:
            json.dump(run_info, f, indent=2)

        all_metadata[name] = metadata
        print(f"[{name}] Residual best: {metadata['residual_best_accuracy']:.3f} at layer {metadata['residual_best_key']}")

        del residual_activations
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    cleanup_model(model, tokenizer)

    pooling_suffix = "" if args.pooling == "mean" else f"_{args.pooling.replace('mean_', '')}"
    summary_path = Path(args.output_dir) / f"category_residual_summary{pooling_suffix}.json"
    with open(summary_path, "w") as f:
        json.dump(all_metadata, f, indent=2)
    print(f"\nAll categories done. Summary written to {summary_path}")
    for name, meta in all_metadata.items():
        print(f"  {name}: acc={meta['residual_best_accuracy']:.3f} at layer {meta['residual_best_key']}, auc={meta['residual_best_auc']}")


if __name__ == "__main__":
    main()
