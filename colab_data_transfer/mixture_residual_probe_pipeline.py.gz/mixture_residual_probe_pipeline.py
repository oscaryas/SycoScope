#!/usr/bin/env python3
"""
Trains residual-stream-only linear probes on results/generations/
sycophancy_mixture/mixture.jsonl (the balanced 4-way sycophancy/not-
sycophancy mixture built by build_sycophancy_mixture.py).

Unlike oeq_probe_pipeline.py / sypr_probe_pipeline.py, which call
sycophancy_probes.collect_activations (always extracts MHA + MLP + residual
via register_hooks, then trains all three), this skips MHA/MLP entirely --
both the hook registration and the probe training for them are wasted work
(1024 MHA probes + 32 MLP probes) when only the residual stream is wanted.
Residual activations come for free from output_hidden_states, no hooks
needed, so the lean extraction loop below only does that.

The mixture is already exactly balanced (n positive == n negative per
category, and therefore overall), so there's no undersample/upweight
distinction to sweep -- both would behave identically on already-balanced
data. Trained once with the (default) undersample balance_method.

Optionally fixes the moral category's truncation issue: the mixture's
`moral` rows store one concatenated (original post + flipped story) text,
pooled over a single ~1024-token-truncated forward pass, so for many pairs
the flipped-story half never enters the activation at all. Passing --judged
a flip-paired judged file (e.g. AITA-NTA-FLIP_moral_sycophancy_judged.jsonl)
switches moral-category rows to two separate forward passes (original post,
flipped story), averaged per layer -- the same fix moral_avg_residual_
probe_pipeline.py uses for the moral-only probe, folded into the combined
extraction. Every other category still gets a single forward pass over
row["text"], unchanged. Omitting --judged (the default) leaves ALL rows,
including moral, on the original single-pass behavior.

Usage:
    python mixture_residual_probe_pipeline.py \
        --input results/generations/sycophancy_mixture/mixture.jsonl \
        --output-dir results/probing/sycophancy_mixture_residual \
        --model meta-llama/Meta-Llama-3-8B-Instruct

    # with the moral two-pass-averaged fix enabled:
    python mixture_residual_probe_pipeline.py \
        --input results/generations/sycophancy_mixture/mixture.jsonl \
        --judged results/generations/AITA-NTA-FLIP_moral_sycophancy_judged.jsonl \
        --output-dir results/probing/sycophancy_mixture_residual \
        --model meta-llama/Meta-Llama-3-8B-Instruct
"""
import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SYCOPHANCY_DIR = HERE.parent
REPO_ROOT = HERE.parents[3]
for p in (SYCOPHANCY_DIR, REPO_ROOT):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from utils.model import load_model_and_tokenizer, cleanup as cleanup_model
from utils.inference import build_chat_prompt
from sycophancy_model_registry import get_model_config
from sycophancy_probes import _pool, _pool_indices, _first_sentence_length, train_residual_probes, save_probe_results


def load_mixture(path: Path) -> list:
    return [json.loads(line) for line in open(path, encoding="utf-8")]


def load_judged_by_row_id(path: Path) -> dict:
    return {rec["row_id"]: rec for line in open(path, encoding="utf-8") for rec in [json.loads(line)]}


def collect_residual_only(model, tokenizer, texts: list, model_config: dict, max_length: int = 1024, pooling: str = "mean") -> np.ndarray:
    """
    Residual-stream activations only -- no MHA/MLP hooks registered, since
    residual comes directly from output_hidden_states. Same pooling
    convention as sycophancy_probes.collect_activations (mean over the
    response span after the answer_token_id delimiter, or whole sequence if
    not found) so results are comparable to the MHA/MLP-inclusive pipelines.

    pooling="mean_first_sentence" is special-cased here (rather than in
    _pool) since it needs the tokenizer to find where the first sentence
    ends -- computed per-example via _first_sentence_length, then pooled
    with _pool_indices over that explicit token range.

    Returns (n_layers, n_examples, hidden_dim).
    """
    n_layers = model_config["n_layers"]
    answer_token_id = model_config.get("answer_token_id")
    device = next(model.parameters()).device

    all_res = []
    model.eval()
    with torch.no_grad():
        for i, text in enumerate(texts):
            inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=max_length)
            input_ids = inputs["input_ids"]
            if str(device) != "cpu":
                inputs = {k: v.to(device) for k, v in inputs.items()}

            outputs = model(**inputs, output_hidden_states=True)

            if answer_token_id is not None:
                token_list = input_ids[0].tolist()
                positions = [j for j, t in enumerate(token_list) if t == answer_token_id]
                pos = positions[-1] if positions else -1
            else:
                pos = -1

            if pooling == "mean_first_sentence":
                start = pos + 1 if pos != -1 else 0
                sent_len = _first_sentence_length(tokenizer, token_list[start:])
                indices = list(range(start, start + sent_len))

            res_example = np.zeros((n_layers, model_config["hidden_dim"]), dtype=np.float32)
            hidden_states = outputs.hidden_states
            for layer_idx in range(n_layers):
                if pooling == "mean_first_sentence":
                    hs = _pool_indices(hidden_states[layer_idx + 1][0], indices).cpu().float().numpy().astype(np.float32)
                else:
                    hs = _pool(hidden_states[layer_idx + 1][0], pos, pooling).cpu().float().numpy().astype(np.float32)
                res_example[layer_idx] = hs
            all_res.append(res_example)

            if (i + 1) % 50 == 0:
                print(f"  Extracted {i+1}/{len(texts)} examples")
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

    res_arr = np.stack(all_res, axis=0)       # (n_examples, n_layers, hidden_dim)
    return res_arr.transpose(1, 0, 2)         # (n_layers, n_examples, hidden_dim)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=str, default=str(SYCOPHANCY_DIR / "results" / "generations" / "sycophancy_mixture" / "mixture.jsonl"))
    parser.add_argument(
        "--judged", type=str, default=None,
        help="Path to a flip-paired judged file (e.g. AITA-NTA-FLIP_moral_sycophancy_judged.jsonl). "
             "When given, moral-category rows are re-extracted as two separate forward passes "
             "(original post, flipped story) averaged per layer instead of one concatenated/truncated "
             "pass -- the moral_avg_residual_probe_pipeline.py fix. Omit to leave all rows, including "
             "moral, on the original single forward pass over row['text'].",
    )
    parser.add_argument("--output-dir", type=str, default=str(SYCOPHANCY_DIR / "results" / "probing" / "sycophancy_mixture_residual"))
    parser.add_argument("--model", type=str, default="meta-llama/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--balance-method", type=str, default="undersample", choices=["undersample", "upweight"])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--pooling", type=str, default="mean",
                         help="'mean' (full response span, default), 'mean_first<K>' (e.g. 'mean_first5'), "
                              "or 'mean_first_sentence'. Non-'mean' values get a suffix appended to "
                              "--output-dir (if left at its default) so results land alongside the "
                              "full-response run rather than overwriting it.")
    args = parser.parse_args()
    if args.pooling != "mean" and args.output_dir == str(SYCOPHANCY_DIR / "results" / "probing" / "sycophancy_mixture_residual"):
        suffix = "_first_sentence" if args.pooling == "mean_first_sentence" else f"_{args.pooling.replace('mean_', '')}"
        args.output_dir += suffix

    rows = load_mixture(Path(args.input))
    labels = np.array([r["label"] for r in rows], dtype=np.float32)
    categories = [r["category"] for r in rows]
    n_pos = int((labels == 1).sum())
    n_neg = int((labels == 0).sum())
    print(f"Loaded {len(rows)} rows from {args.input} ({n_pos} positive / {n_neg} negative)")
    print(f"Category breakdown: {dict(Counter(categories))}")

    moral_idx = [i for i, r in enumerate(rows) if r["category"] == "moral"] if args.judged else []
    other_idx = [i for i in range(len(rows)) if i not in set(moral_idx)]

    judged_by_row_id = {}
    if args.judged:
        judged_by_row_id = load_judged_by_row_id(Path(args.judged))
        missing = [i for i in moral_idx if rows[i]["meta"]["row_id"] not in judged_by_row_id]
        if missing:
            raise ValueError(f"{len(missing)} moral row_ids not found in {args.judged}")
        print(f"--judged given: {len(moral_idx)} moral rows will use two-pass averaged extraction; "
              f"{len(other_idx)} other rows stay single-pass.")

    print(f"\nLoading {args.model}...")
    model, tokenizer = load_model_and_tokenizer(args.model)
    model_config = get_model_config(args.model)
    model_config["model_name"] = args.model
    n_layers = model_config["n_layers"]
    hidden_dim = model_config["hidden_dim"]

    combined = np.zeros((n_layers, len(rows), hidden_dim), dtype=np.float32)

    other_texts = [rows[i]["text"] for i in other_idx]
    print(f"\nExtracting residual-stream activations for {len(other_texts)} rows (single pass each, {n_layers} layers, pooling={args.pooling!r})...")
    other_activations = collect_residual_only(model, tokenizer, other_texts, model_config, pooling=args.pooling)
    for slot, i in enumerate(other_idx):
        combined[:, i, :] = other_activations[:, slot, :]

    if moral_idx:
        moral_og_texts = [
            build_chat_prompt(tokenizer, judged_by_row_id[rows[i]["meta"]["row_id"]]["original_post_prompt"], system_prompt=None)
            + judged_by_row_id[rows[i]["meta"]["row_id"]]["original_post_response"]
            for i in moral_idx
        ]
        moral_flip_texts = [
            build_chat_prompt(tokenizer, judged_by_row_id[rows[i]["meta"]["row_id"]]["flipped_story_prompt"], system_prompt=None)
            + judged_by_row_id[rows[i]["meta"]["row_id"]]["flipped_story_response"]
            for i in moral_idx
        ]
        print(f"\nExtracting residual activations for {len(moral_idx)} moral rows, original-post side...")
        moral_og_activations = collect_residual_only(model, tokenizer, moral_og_texts, model_config, pooling=args.pooling)
        print(f"\nExtracting residual activations for {len(moral_idx)} moral rows, flipped-story side...")
        moral_flip_activations = collect_residual_only(model, tokenizer, moral_flip_texts, model_config, pooling=args.pooling)
        moral_activations = (moral_og_activations + moral_flip_activations) / 2.0
        for slot, i in enumerate(moral_idx):
            combined[:, i, :] = moral_activations[:, slot, :]

    cleanup_model(model, tokenizer)

    print(f"\nTraining residual probes ({n_layers} layers, balance_method={args.balance_method})...")
    res_acc, res_ci, res_states, res_auc, res_auc_ci = train_residual_probes(
        combined, labels, n_layers, balance_method=args.balance_method, seed=args.seed,
    )

    results = {
        "mha_accuracy": {}, "mha_ci": {}, "mha_states": {}, "mha_auc": {}, "mha_auc_ci": {},
        "mlp_accuracy": {}, "mlp_ci": {}, "mlp_states": {}, "mlp_auc": {}, "mlp_auc_ci": {},
        "residual_accuracy": res_acc, "residual_ci": res_ci, "residual_states": res_states,
        "residual_auc": res_auc, "residual_auc_ci": res_auc_ci,
    }
    metadata = save_probe_results(results, args.output_dir, model_name=args.model)

    run_info = {
        "input": str(args.input),
        "judged": str(args.judged) if args.judged else None,
        "n_total": len(rows),
        "n_pos": n_pos,
        "n_neg": n_neg,
        "n_moral_two_pass": len(moral_idx),
        "n_single_pass": len(other_idx),
        "category_breakdown": dict(Counter(categories)),
        "balance_method": args.balance_method,
        "model": args.model,
        "seed": args.seed,
        "pooling": args.pooling,
        "method": (
            "moral rows re-extracted as two separate forward passes (original post, flipped story) "
            "averaged per layer, instead of one concatenated/truncated pass; all other categories "
            "single-pass over row['text']"
            if args.judged else
            "single forward pass per row over row['text'] for all categories (no moral two-pass fix "
            "applied; pass --judged to enable it)"
        ),
    }
    with open(Path(args.output_dir) / "run_info.json", "w") as f:
        json.dump(run_info, f, indent=2)

    print(f"\nDone. Residual best: {metadata['residual_best_accuracy']:.3f} at layer {metadata['residual_best_key']}")


if __name__ == "__main__":
    main()
